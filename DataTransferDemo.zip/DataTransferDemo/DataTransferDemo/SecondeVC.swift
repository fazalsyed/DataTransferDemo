//
//  SecondeVC.swift
//  DataTransferDemo
//
//  Created by syed fazal abbas on 08/05/23.
//

import UIKit

class SecondeVC: UIViewController {
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblGmail: UILabel!
    var stringName : String? = nil
    var StringGmail : String? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        lblName.text = stringName
        lblGmail.text = StringGmail
        UiView()
    }
    func UiView(){
        lblName.layer.borderWidth = 1
        lblName.layer.borderColor = UIColor.black.cgColor
        lblGmail.layer.borderWidth = 1
        lblGmail.layer.borderColor = UIColor.black.cgColor
    }
}
