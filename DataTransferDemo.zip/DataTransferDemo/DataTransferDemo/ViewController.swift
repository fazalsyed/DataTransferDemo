//
//  ViewController.swift
//  DataTransferDemo
//
//  Created by syed fazal abbas on 08/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtGmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
    }


    @IBAction func btnTappedSubmit(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecondeVC" ) as? SecondeVC
        vc?.stringName = txtName.text
        vc?.StringGmail = txtGmail.text
        self.navigationController?.pushViewController(vc!, animated: true)
    }
}

